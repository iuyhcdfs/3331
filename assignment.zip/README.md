Routing Performance for comp3331
david sicong zhou and christopher phibbs

make runs a test run. youll have to sub in your values

all code is within RoutingPerformance.c